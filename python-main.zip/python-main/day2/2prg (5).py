test=input("Enter the expression:")
res=eval(test)
print(test,"=",int(res))
